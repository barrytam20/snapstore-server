(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	module.exports = __webpack_require__(1);


/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	'user strict';
	"use strict";
	var firebaseUser_1 = __webpack_require__(2);
	var slsResponse_1 = __webpack_require__(6);
	var user = new firebaseUser_1.User();
	module.exports.createUser = function (event, context, callback) {
	    var params = event.body;
	    console.log('create user params: ' + JSON.stringify(params));
	    user.createUser(params, function (status, postUserResponse) {
	        context.callbackWaitsForEmptyEventLoop = false;
	        slsResponse_1.slsResponse(status, postUserResponse, callback);
	    });
	};
	module.exports.getUser = function (event, context, callback) {
	    var userId = event.path.userId;
	    user.getUser(userId, function (status, getUserResponse) {
	        context.callbackWaitsForEmptyEventLoop = false;
	        slsResponse_1.slsResponse(status, getUserResponse, callback);
	    });
	};
	module.exports.findUserByEmail = function (event, context, callback) {
	    var email = event.path.email;
	    user.findUserByEmail(email, function (status, getUserResponse) {
	        context.callbackWaitsForEmptyEventLoop = false;
	        slsResponse_1.slsResponse(status, getUserResponse, callback);
	    });
	};
	module.exports.updateUser = function (event, context, callback) {
	    var userId = event.path.user_id;
	    var params = event.body;
	    console.log('update user params: ' + JSON.stringify(params));
	    user.updateUser(userId, params, function (status, updateUserResponse) {
	        context.callbackWaitsForEmptyEventLoop = false;
	        slsResponse_1.slsResponse(status, updateUserResponse, callback);
	    });
	};


/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	var init_1 = __webpack_require__(3);
	var User = (function () {
	    function User() {
	        this.fbInstance = init_1.FB.initFirebase('user');
	        this.userRef = this.fbInstance.database().ref('/user');
	    }
	    User.prototype.createUser = function (userData, callback) {
	        var _this = this;
	        console.log(JSON.stringify(userData));
	        this.findUserByEmailHelper(userData.email, function (userId) {
	            if (userId === null) {
	                var newUser_1 = _this.userRef.push();
	                newUser_1.set(userData).then(function () {
	                    console.log('SUCCESS, User created: ' + newUser_1.key);
	                    callback(200, { user_id: newUser_1.key });
	                }).catch(function (error) {
	                    console.log('ERROR, Adding user : ' + error);
	                    callback(500, null);
	                });
	            }
	            else {
	                console.log('ERROR: User already exists with email');
	                callback(403, { "userId": userId, "message": "user already exists" });
	            }
	        });
	    };
	    User.prototype.getUser = function (userId, callback) {
	        var childUserRef = this.userRef.child(userId);
	        childUserRef.once('value', function (snapshot) {
	            if (snapshot.exists()) {
	                console.log('SUCCESS: Get user: ' + userId);
	                var user = snapshot.val();
	                user.user_id = userId;
	                callback(200, user);
	            }
	            else {
	                console.log('SUCCESS: Get user, no match: ' + userId);
	                callback(404, userId + ' not found');
	            }
	        });
	    };
	    User.prototype.findUserByEmail = function (email, callback) {
	        var _this = this;
	        this.findUserByEmailHelper(email, function (userId) {
	            if (!userId) {
	                callback(404, console.log('ERROR: Account not found for phone: ' + email));
	            }
	            else {
	                var singleUserRef = _this.userRef.child(userId);
	                singleUserRef.once('value', function (snapshot) {
	                    if (snapshot.exists()) {
	                        var data = snapshot.val();
	                        data.user_id = userId;
	                        callback(200, data);
	                    }
	                    else {
	                        callback(500, console.log('ERROR, Retrieving user for: ' + userId));
	                    }
	                });
	            }
	        });
	    };
	    User.prototype.updateUser = function (userId, userData, callback) {
	        var childUserRef = this.userRef.child(userId);
	        childUserRef.once('value', function (snapshot) {
	            if (snapshot.exists()) {
	                childUserRef.update(userData).then(function () {
	                    callback(200, console.log('SUCCESS: Update user: ' + userId));
	                }).catch(function (error) {
	                    callback(500, console.log('ERROR, Update user: ' + error));
	                });
	            }
	            else {
	                console.log('SUCCESS: Update user, no match: ' + userId);
	                callback(200, null);
	            }
	        });
	    };
	    User.prototype.findUserByEmailHelper = function (email, callback) {
	        var singleUserRef = this.userRef.orderByChild('number').equalTo(email);
	        singleUserRef.once('value', function (snapshot) {
	            if (snapshot.exists()) {
	                snapshot.forEach(function (item) {
	                    console.log('Account found account for phone: ' + email);
	                    callback(item.key);
	                    return true; // Cancels further enumeration
	                });
	            }
	            else {
	                console.log('Account DNE for phone: ' + email);
	                callback(null);
	            }
	        });
	    };
	    return User;
	}());
	exports.User = User;


/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	var admin = __webpack_require__(4);
	var serviceAccount = __webpack_require__(5);
	var FB = (function () {
	    function FB() {
	    }
	    FB.initFirebase = function (name) {
	        if (!this.fbInstance) {
	            console.log('initializing firebase');
	            this.fbInstance = admin.initializeApp({
	                credential: admin.credential.cert(serviceAccount),
	                databaseURL: 'https://snapstore-2f947.firebaseio.com/'
	            });
	        }
	        return this.fbInstance;
	    };
	    return FB;
	}());
	exports.FB = FB;


/***/ },
/* 4 */
/***/ function(module, exports) {

	module.exports = require("firebase-admin");

/***/ },
/* 5 */
/***/ function(module, exports) {

	module.exports = {
		"type": "service_account",
		"project_id": "snapstore-2f947",
		"private_key_id": "bc6435fcb76c7e40cc56f66eb0abf6af470d1876",
		"private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDklUq4VzKQ1HDJ\nyw2RdqK2UwBMBIBZVa8noUT5faOQWntuPkt9zs95oaXIpMdAfSJShZxdd6QgvhJG\nZwW42BzrU7YNidSAPonSBWd3+m68p62rW6CB3re4Yx8R8brGsNgA/miT5ds8P0XZ\nzywvaonnMfs4NW09Ku+GrfbCP3EDzgsjaQEtoGl1laNfhEZzuIvK9PGd1/MKrziv\nqK+bWnzpncvm4puxfqbbIltIrPSyhm8yxfbs/ni1zJluIkhWTUGXPoWoxXi4VlKP\nbtAwR9yUDHr//BlEbUHlaDRqa4GjSVfYJu/pQAz33DkziAAj2laKnze4G20ZgCnt\n7o9ErqtbAgMBAAECggEAOLdGO+j+1eqwNZGZQz+BbeW4TCRNyFy3QgkEuTbQT6/z\nsk3oo0WeOxq9rMQd4EVsL7eRLavS4IDovekwBUYyHr29jSxmuo9J2P+YRa+wrESa\nlcr9T1v4j9qgSe6Fnmkgn1aAkjnVJOS6Kyn5V6aCowfGwpKXETdHCU6+zEG7g+qy\nwKXb+hvZdKntYLyxrMtF7pARYi8xWa71b1QcNiMAmG6XCn4f//uloIpiZkWwc1pw\ng461rQv/BgTmHIaTvy869AlegoWDIGylQRWGDjysOOwDhHZn2NwNJp/lZZQY1vJn\nh5zpzcd9aWBDInnDLySBfbxkk/RWMpf3HMdxCM/HkQKBgQD6jWcxN6Nx8F2cf4hT\n2b9QvOFUiStuT9lGVAi7rZoDBkJMdmaK+cdLApKg8nYM63AZGPnspu841e/oiQ+4\njin20AXdAjCnHn3IoYPfVQ20vPr/rViYKmt6KBrZjiTXtngL77ioUhOa+lwB9Sv3\n6F+cct21DaPInzrAl4F856Y9YwKBgQDpjZs4SqBTN2Ts/5hpqNYAchfVZ+oxHqSG\n5/d+AiLL60X4LDAk1fLfyWKDroxRCTXbNaCh6niJ8igpawE1V0Z52JzK6NwcBR+f\n1RgfIR2PCwhoH9YtP8rOCrXvxI8beuFY2TtL8MNzcNMom0cFNg2Jtc244UVPIogi\nv8lYcrbXqQKBgQDnr34u2t4+7CAEKUItF3t7800CWN1aYmfuSqLQuZVjGpSQFCR6\nesK5MCXawpo7FDNSYfApz6wCiIISKzvoUz2mx3HEjtPilaWGsyQ4jnPgH6iSaP81\npnRAP3mkl3amKksT7pZ4v3z1oHEYNlh0I+LVzroJRBWh3Ov9T5wjninxNQKBgQCp\nS96iVWYWLGdabIR8wsgtloa0SRk39fBpYijDDKVQkAEuPkm/yd6+XWqt7Y8FBtol\nRqBj/mTWCdUXANvlYJhTprMxWs6C+SvNXliX6BdXIzY61Ckar81Awf7UCPV7g/1p\nvD4BdEsZmUVXgAdhPadelYzEYXcuP+fS2JcJKE5l0QKBgQDXvoMDXPljOjvt7tfS\nHt8afGAAmpCDfbV4uhmO7wvKiTTL67KRJjfYfRZix44fK64pca0+ogEwfNKLhZKF\nxI8RwEZfvuEU6XwN1f3+mwJg0PQSqc52x7BWneEXjgVEJEX4gRQibUWWeZJA/Xhm\n4VY19v4cg4ZdK7YtNzRmY4WSsQ==\n-----END PRIVATE KEY-----\n",
		"client_email": "snapstore-2f947@appspot.gserviceaccount.com",
		"client_id": "117577102236209299347",
		"auth_uri": "https://accounts.google.com/o/oauth2/auth",
		"token_uri": "https://accounts.google.com/o/oauth2/token",
		"auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
		"client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/snapstore-2f947%40appspot.gserviceaccount.com"
	};

/***/ },
/* 6 */
/***/ function(module, exports) {

	"use strict";
	function slsResponse(status, body, callback) {
	    console.log('serverless response: ' + JSON.stringify(body));
	    if (status !== 200) {
	        //TODO: use es6 string formatting
	        body = (typeof body === 'object') ? JSON.stringify(body) : body;
	        callback(new Error('[' + status + '] ' + body));
	    }
	    else {
	        callback(null, body);
	    }
	}
	exports.slsResponse = slsResponse;


/***/ }
/******/ ])));